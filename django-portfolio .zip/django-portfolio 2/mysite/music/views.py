from django.shortcuts import get_object_or_404, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, UpdateView, DeleteView
from .models import Artist, Album
from .forms import ArtistForm, AlbumForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin

def home(request):
    return render(request, 'home.html')

def artists(request):
    artists = Artist.objects.all()
    return render(request, 'music/artists.html', {'artists': artists})

def artist_detail(request, pk):
    artist = get_object_or_404(Artist, pk=pk)
    return render(request, 'music/artist_detail.html', {'artist': artist})

class ArtistCreateView(LoginRequiredMixin, CreateView):
    model = Artist
    form_class = ArtistForm
    template_name = 'music/artist_form.html'
    success_url = reverse_lazy('artists')

class ArtistUpdateView(LoginRequiredMixin, UpdateView):
    model = Artist
    form_class = ArtistForm
    template_name = 'music/artist_form.html'
    success_url = reverse_lazy('artists')

class ArtistDeleteView(LoginRequiredMixin, DeleteView):
    model = Artist
    template_name = 'music/artist_confirm_delete.html'
    success_url = reverse_lazy('artists')

def albums(request):
    albums = Album.objects.all()
    return render(request, 'music/albums.html', {'albums': albums})

def album_detail(request, pk):
    album = get_object_or_404(Album, pk=pk)
    return render(request, 'music/album_detail.html', {'album': album})

class AlbumCreateView(LoginRequiredMixin, CreateView):
    model = Album
    form_class = AlbumForm
    template_name = 'music/album_form.html'
    success_url = reverse_lazy('albums')

class AlbumUpdateView(LoginRequiredMixin, UpdateView):
    model = Album
    form_class = AlbumForm
    template_name = 'music/album_form.html'
    success_url = reverse_lazy('albums')

class AlbumDeleteView(LoginRequiredMixin, DeleteView):
    model = Album
    template_name = 'music/album_confirm_delete.html'
    success_url = reverse_lazy('albums')
