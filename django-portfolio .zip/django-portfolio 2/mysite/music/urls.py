from django.urls import path
from . import views
from .views import ArtistCreateView, ArtistUpdateView, ArtistDeleteView, AlbumCreateView, AlbumUpdateView, AlbumDeleteView

urlpatterns = [
    path('', views.home, name='home'),
    path('artists/', views.artists, name='artists'),
    path('artists/<int:pk>/', views.artist_detail, name='artist_detail'),
    path('albums/', views.albums, name='albums'),
    path('albums/<int:pk>/', views.album_detail, name='album_detail'),
    path('artists/add/', ArtistCreateView.as_view(), name='artist_add'),
    path('artists/<int:pk>/update/', ArtistUpdateView.as_view(), name='artist_update'),
    path('artists/<int:pk>/delete/', ArtistDeleteView.as_view(), name='artist_delete'),
    path('albums/add/', AlbumCreateView.as_view(), name='album_add'),
    path('albums/<int:pk>/update/', AlbumUpdateView.as_view(), name='album_update'),
    path('albums/<int:pk>/delete/', AlbumDeleteView.as_view(), name='album_delete'),
]
